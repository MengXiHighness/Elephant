﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 有关程序集的常规信息通过下列属性集
// 控制。更改这些属性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("数据访问层代码构造器")]
[assembly: AssemblyDescription("数据访问层代码构造器（Parameter方式）")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Maticsoft")]
[assembly: AssemblyProduct("Codematic.NET代码自动生成器")]
[assembly: AssemblyCopyright("Copyright (C) Maticsoft 2004-2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		


// 将 ComVisible 设置为 false 使此程序集中的类型
// 对 COM 组件不可见。如果需要从 COM 访问此程序集中的类型，
// 则将该类型上的 ComVisible 属性设置为 true。
[assembly: ComVisible(false)]

// 如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
[assembly: Guid("575279ca-c75c-41be-8496-7162637d9745")]

[assembly: AssemblyVersion("2.1.9")]
[assembly: AssemblyFileVersion("2.1.9")]